# CS440-Intro-to-AI
Rutgers CS440 Fa21: Intro to Artificial Intelligence 
